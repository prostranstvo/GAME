const questionBox = document.getElementById("questionBox");
const choicesBox = document.getElementById("choices");
const feedbackBox = document.getElementById("feedback");
const scoreBox = document.getElementById("scoreBox");
const animation = document.getElementById("animation");
const title = document.getElementById("title");
const difficultyScreen = document.getElementById("difficultyScreen");

let index = 0;
let score = 0;
let problems = [];

const randomBetween = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

const generateProblem = (difficulty) => {
  const type = randomBetween(1, difficulty === "hard" ? 5 : difficulty === "medium" ? 4 : 2);
  let question = "", answer = 0;

  switch (type) {
    case 1:
      const x1 = randomBetween(1, 10);
      question = `5x + 7 = ${5 * x1 + 7}. Find x.`;
      answer = x1;
      break;
    case 2:
      const a = randomBetween(10, 30);
      const b = randomBetween(1, a - 1);
      question = `a + b = ${a + b}, b = ${b}. Find a.`;
      answer = a;
      break;
    case 3:
      const x2 = randomBetween(10, 40);
      question = `x + (x + 1) = ${2 * x2 + 1}. Find x.`;
      answer = x2;
      break;
    case 4:
      const x3 = randomBetween(10, 40);
      question = `x + y = ${x3 + (x3 + 28)}, y = x + 28. Find x.`;
      answer = x3;
      break;
    case 5:
      const x4 = randomBetween(10, 40);
      const y = randomBetween(1, 20);
      question = `x + y = ${x4 + y}, x - y = ${x4 - y}. Find x.`;
      answer = x4;
      break;
  }

  return { question, answer };
};

const generateChoices = (correct) => {
  const set = new Set([correct]);
  while (set.size < 3) {
    const offset = randomBetween(1, 5);
    const alt = Math.random() > 0.5 ? correct + offset : correct - offset;
    if (alt >= 0 && !set.has(alt)) set.add(alt);
  }
  return Array.from(set).sort(() => Math.random() - 0.5);
};

const render = () => {
  if (index >= problems.length) {
    document.body.innerHTML = `<h1>Game Over</h1><p>You scored ${score} out of ${problems.length}.</p>`;
    return;
  }

  const { question, answer } = problems[index];
  const choices = generateChoices(answer);

  questionBox.textContent = `Solve: ${question}`;
  choicesBox.innerHTML = "";
  feedbackBox.textContent = "";
  animation.innerHTML = "";

  choices.forEach(val => {
    const btn = document.createElement("div");
    btn.className = "choice";
    btn.textContent = `${val}`;
    btn.onclick = () => handleChoice(val === answer);
    choicesBox.appendChild(btn);
  });
};

const handleChoice = (correct) => {
  if (correct) {
    score++;
    feedbackBox.textContent = "✅ Correct!";
    animation.innerHTML = "🐱";
  } else {
    score = Math.max(0, score - 1);
    feedbackBox.textContent = "❌ Incorrect!";
    animation.innerHTML = "💥";
  }

  animation.style.display = "flex";
  scoreBox.textContent = `Score: ${score}`;

  setTimeout(() => {
    animation.style.display = "none";
    index++;
    render();
  }, 2000);
};

document.addEventListener("keydown", (e) => {
  if (["1", "2", "3"].includes(e.key)) {
    const btns = choicesBox.querySelectorAll(".choice");
    const chosen = btns[parseInt(e.key) - 1];
    if (chosen) chosen.click();
  }
});

document.querySelectorAll(".difficulty-btn").forEach(btn => {
  btn.onclick = () => {
    const difficulty = btn.dataset.level;
    score = 0;
    index = 0;
    problems = Array.from({ length: 20 }, () => generateProblem(difficulty));
    scoreBox.textContent = `Score: ${score}`;
    difficultyScreen.style.display = "none";
    title.style.display = "none";
    questionBox.style.display = "block";
    choicesBox.style.display = "grid";
    feedbackBox.style.display = "block";
    scoreBox.style.display = "block";
    render();
  };
});
